echo -e "# ******************************************************"
echo -e "#                                                      "*
echo -e "# *脚本更新时间：2021年9月14日                         "*
echo -e "#                                                      "*
echo -e "# *正在执行所选择的项目，请耐心等待                    "* 
echo -e "#                                                      "*
echo -e "# *如选错安装的项目，可按Ctrl+Z取消安装                "*
echo -e "#                                                      "*
echo -e "# *如自动添加FSP公网地址失败，可手动添加               "*
echo -e "#                                                      "*
echo -e "# *手动添加格式：bash set_extra_ip.sh 公网IP           "*
echo -e "# ******************************************************"
echo -e "                                                       "
#获取内外网IP地址，端口
LOCAL_IP=$(ip addr | grep -E -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | grep -E -v "^127\.|^255\.|^0\." | head -n 1)
getIpAddress=$(curl -sS --connect-timeout 10 -m 60 https://www.bt.cn/Api/getIpAddress)
panelPort="8080"
if [ $1 = '-434single' ]
then
	echo -e "\033[33m 【你选择的是安装CES v4.34.5.1单机版（含FSP服务器）】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --name=fsp -e addr=127.0.0.1 -e service=base --hostname fsp_server --net=host --restart=always ccr.ccs.tencentyun.com/1040155/fsp:1.7.1.19
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.34.5.1.tar.gz -O ces_linux_zx4.34.5.1.tar.gz
	tar zxvf ces_linux_zx4.34.5.1.tar.gz
	cd ./ces_linux4.34.5.1
	bash server_install.sh single	
fi
if [ $1 = '-434main' ]
then
	echo -e "\033[33m 【你选择安装的是CES v4.34.5.1集群主服务器（含FSP服务器）】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --name=fsp -e addr=127.0.0.1 -e service=base --hostname fsp_server --net=host --restart=always ccr.ccs.tencentyun.com/1040155/fsp:1.7.1.19
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.34.5.1.tar.gz -O ces_linux_zx4.34.5.1.tar.gz
	tar zxvf ces_linux_zx4.34.5.1.tar.gz
	cd ./ces_linux4.34.5.1
	bash server_install.sh cluster main	
fi
if [ $1 = '-434dj' ]
then
	echo -e "\033[33m 【你选择的是只安装CES v4.34.5.1单机版】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.34.5.1.tar.gz -O ces_linux_zx4.34.5.1.tar.gz
	tar zxvf ces_linux_zx4.34.5.1.tar.gz
	cd ./ces_linux4.34.5.1
	bash server_install.sh single
fi
if [ $1 = '-434jq' ]
then
	echo -e "\033[33m 【你选择的是只安装CES v4.34.5.1集群主服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.34.5.1.tar.gz -O ces_linux_zx4.34.5.1.tar.gz
	tar zxvf ces_linux_zx4.34.5.1.tar.gz
	cd ./ces_linux4.34.5.1
	bash server_install.sh cluster main
fi
if [ $1 = '-434node' ]
then
	echo -e "\033[33m 【你选择的是安装CES v4.34.5.1集群节点服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.34.5.1.tar.gz -O ces_linux_zx4.34.5.1.tar.gz
	tar zxvf ces_linux_zx4.34.5.1.tar.gz
	cd ./ces_linux4.34.5.1
	bash server_install.sh cluster node
fi
if [ $1 = '-434face' ]
then
	echo -e "\033[33m 【你选择的是安装CES v4.34.5.1人脸识别服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.34.5.1.tar.gz -O ces_linux_zx4.34.5.1.tar.gz
	tar zxvf ces_linux_zx4.34.5.1.tar.gz
	cd ./ces_linux4.34.5.1
	bash server_install.sh cluster face
fi
if [ $1 = '-431single' ]
then
	echo -e "\033[33m 【你选择的是安装CES v4.31.3.6单机版（含FSP服务器）】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --restart=unless-stopped -p 29100:29100 -p 28000:28000 --name fsp ccr.ccs.tencentyun.com/1040155/fsp:1.4.1.17
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.31.3.5.tar.gz -O ces_linux_zx4.31.3.5.tar.gz
	tar zxvf ces_linux_zx4.31.3.5.tar.gz
	cd ./ces_linux4.31.3.5
	bash server_install.sh single
fi
if [ $1 = '-431main' ]
then
	echo -e "\033[33m 【你选择安装的是CES v4.31.3.6集群主服务器（含FSP服务器）】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --restart=unless-stopped -p 29100:29100 -p 28000:28000 --name fsp ccr.ccs.tencentyun.com/1040155/fsp:1.4.1.17
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.31.3.5.tar.gz -O ces_linux_zx4.31.3.5.tar.gz
	tar zxvf ces_linux_zx4.31.3.5.tar.gz
	cd ./ces_linux4.31.3.5
	bash server_install.sh cluster main
fi
if [ $1 = '-431node' ]
then
	echo -e "\033[33m 【你选择的是安装CES v4.31.3.6集群节点服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.31.3.5.tar.gz -O ces_linux_zx4.31.3.5.tar.gz
	tar zxvf ces_linux_zx4.31.3.5.tar.gz
	cd ./ces_linux4.31.3.5
	bash server_install.sh cluster node
fi
if [ $1 = '-431dj' ]
then
	echo -e "\033[33m 【你选择的是只安装CES v4.31.3.6单机版】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.31.3.5.tar.gz -O ces_linux_zx4.31.3.5.tar.gz
	tar zxvf ces_linux_zx4.31.3.5.tar.gz
	cd ./ces_linux4.31.3.5
	bash server_install.sh single
fi
if [ $1 = '-431jq' ]
then
	echo -e "\033[33m 【你选择的是只安装CES v4.31.3.6集群主服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.31.3.5.tar.gz -O ces_linux_zx4.31.3.5.tar.gz
	tar zxvf ces_linux_zx4.31.3.5.tar.gz
	cd ./ces_linux4.31.3.5
	bash server_install.sh cluster main
fi
if [ $1 = '-432single' ]
then
	echo -e "\033[33m 【你选择的是安装CES v4.32.8.5单机版（含FSP服务器）】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --restart=unless-stopped -p 29100:29100 -p 28000:28000 --name fsp ccr.ccs.tencentyun.com/1040155/fsp:1.6.4.4
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.32.8.5.tar.gz -O ces_linux_zx4.32.8.5.tar.gz
	tar zxvf ces_linux_zx4.32.8.5.tar.gz
	cd ./ces_linux4.32.8.5
	bash server_install.sh single
fi
if [ $1 = '-432main' ]
then
	echo -e "\033[33m 【你选择的是安装CES v4.32.8.5集群主服务器（含FSP服务器）】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --restart=unless-stopped -p 29100:29100 -p 28000:28000 --name fsp ccr.ccs.tencentyun.com/1040155/fsp:1.6.4.4
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.32.8.5.tar.gz -O ces_linux_zx4.32.8.5.tar.gz
	tar zxvf ces_linux_zx4.32.8.5.tar.gz
	cd ./ces_linux4.32.8.5
	bash server_install.sh cluster main
fi
if [ $1 = '-432node' ]
then
	echo -e "\033[33m 【你选择的是安装CES v4.32.8.5集群节点服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.32.8.5.tar.gz -O ces_linux_zx4.32.8.5.tar.gz
	tar zxvf ces_linux_zx4.32.8.5.tar.gz
	cd ./ces_linux4.32.8.5
	bash server_install.sh cluster node
fi
if [ $1 = '-432face' ]
then
	echo -e "\033[33m 【你选择的是安装CES v4.32.8.5人脸识别服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.32.8.5.tar.gz -O ces_linux_zx4.32.8.5.tar.gz
	tar zxvf ces_linux_zx4.32.8.5.tar.gz
	cd ./ces_linux4.32.8.5
	bash server_install.sh cluster face
fi
if [ $1 = '-432dj' ]
then
	echo -e "\033[33m 【你选择的是只安装CES v4.32.8.5单机版】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.32.8.5.tar.gz -O ces_linux_zx4.32.8.5.tar.gz
	tar zxvf ces_linux_zx4.32.8.5.tar.gz
	cd ./ces_linux4.32.8.5
	bash server_install.sh single
fi
if [ $1 = '-432jq' ]
then
	echo -e "\033[33m 【你选择的是只安装CES v4.32.8.5集群主服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	wget https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/中性版/ces_linux_zx4.32.8.5.tar.gz -O ces_linux_zx4.32.8.5.tar.gz
	tar zxvf ces_linux_zx4.32.8.5.tar.gz
	cd ./ces_linux4.32.8.5
	bash server_install.sh cluster main
fi
if [ $1 = '-gc431jq' ]
then
	echo -e "\033[33m 【你选择的是只安装国产化CES v4.31.2.16集群主服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/ARM/ces_linux_arm4.31.2.16.tar.gz -O ces_linux_arm4.31.2.16.tar.g
	tar zxvf ces_linux_arm4.31.2.16.tar.g
	cd ./ces_linux4.31.2.16
	bash server_install.sh cluster main
fi
if [ $1 = '-gc431dj' ]
then
	echo -e "\033[33m 【你选择的是只安装国产化CES v4.31.2.16单机版服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/ARM/ces_linux_arm4.31.2.16.tar.gz -O ces_linux_arm4.31.2.16.tar.g
	tar zxvf ces_linux_arm4.31.2.16.tar.g
	cd ./ces_linux4.31.2.16
	bash server_install.sh single
fi
if [ $1 = '-gc431node' ]
then
	echo -e "\033[33m 【你选择的是只安装国产化CES v4.31.2.16集群节点服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	https://yaohst.com/Aliyun/好视通/02好视通视频会议企业版服务器/linux服务端/ARM/ces_linux_arm4.31.2.16.tar.gz -O ces_linux_arm4.31.2.16.tar.g
	tar zxvf ces_linux_arm4.31.2.16.tar.g
	cd ./ces_linux4.31.2.16
	bash server_install.sh cluster node
fi
if [ $1 = '-141fsp' ]
then
	echo -e "\033[33m 【你选择的是安装FSP v1.4.1.17服务器（仅安装FSP服务器）】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --restart=unless-stopped -p 29100:29100 -p 28000:28000 --name fsp ccr.ccs.tencentyun.com/1040155/fsp:1.4.1.17
fi
if [ $1 = '-164fsp' ]
then
	echo -e "\033[33m 【你选择的是安装FSP v1.6.4.4服务器（仅安装FSP服务器）】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --restart=unless-stopped -p 29100:29100 -p 28000:28000 --name fsp ccr.ccs.tencentyun.com/1040155/fsp:1.6.4.4
fi
if [ $1 = '-171fsp' ]
then
	echo -e "\033[33m 【你选择的是安装FSP v1.7.1.19服务器（仅安装FSP服务器）】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --name=fsp -e addr=127.0.0.1 -e service=base --hostname fsp_server --net=host --restart=always ccr.ccs.tencentyun.com/1040155/fsp:1.7.1.19	
fi
if [ $1 = '-rtmp' ]
then
	echo -e "\033[33m 【你选择的是安装RTMP/WebRTC/HLS/HTTP-FLV/SRT实时视频服务器】 \033[0m"
	echo -e "\n"
	sleep 5s
	curl -sSL https://get.docker.com/ | sh
	systemctl enable docker
	systemctl start docker
	docker run -d --restart=unless-stopped -p 1935:1935 -p 1985:1985 -p 8080:8080 -p 8000:8000/udp --name srs4 ccr.ccs.tencentyun.com/1040155/srs4
fi
if [ $1 = '-xiezai' ]
then
	echo -e "\033[33m 【你选择的是卸载CES服务器（请注意备份好数据）】 \033[0m"
	echo -e "\n"
	sleep 5s
	cd /usr/local/hst
	bash server_uninstall.sh
fi
if [ $1 = '-resetadmin' ]
then
	echo -e "\033[33m 【你选择的是重置后台admin密码】 \033[0m"
	echo -e "\n"
	sleep 5s	
	mysql -u admin -pFsEntMeeting.com -P3308<"resetadmin.sql"
fi
if [ $1 = '-setip' ]
then
	echo -e "\033[33m 【你选择的是自动添加FSP公网地址（1.7.1.19以上才需要执行）】 \033[0m"
	echo -e "\n"
	sleep 5s	
	bash set_extra_ip.sh ${getIpAddress}
fi
#关闭防火墙
systemctl stop firewalld.service
#禁用防火墙
systemctl disable firewalld.service
echo -e "                                                                                "
echo -e "#*******************************************************************************"*                      
echo -e "#                                                                               "
echo -e "# *脚本执行完成                                                                 "
echo -e "#                                                                               "
echo -e "# *FSP默认端口：28000、29100 （注：4.34之后的为28000和20020端口)                "
echo -e "#                                                                               "
echo -e "# *CES默认端口：1089、8080、8443                                                "
echo -e "#                                                                               "
echo -e "# *内网后台地址（仅限单机版和集群主服务器）：http://${LOCAL_IP}:${panelPort}    "
echo -e "#                                                                               "
echo -e "# *外网后台地址（仅限单机版和集群主服务器）：https://${getIpAddress}:8443       "
echo -e "#                                                                               "
echo -e "# *如需外网使用请在路由器中映射上述端口                                         "
echo -e "#                                                                               "
echo -e "# *后台默认用户名密码均为admin，请您及时修改后台默认密码                        "
echo -e "#                                                                               "
echo -e "# *使用过程中如有问题，请拨打400-1699-666转1号键联系我们                        "
echo -e "#                                                                               "
echo -e "# *本脚本作者：唐辉                                                             "
echo -e "#                                                                               "
echo -e "# *博客地址：https://www.yaohst.com                                             "
echo -e "#                                                                               "
echo -e "# ******************************************************************************"
echo -e "                                                                                "

#删除安装脚本
rm -rf install.sh
rm -rf hstinstall.sh
rm -rf zxinstall.sh
rm -rf ces.sh
rm -rf hstces.sh
rm -rf zxces.sh
rm -rf resetadmin.sql
rm -rf install.zip